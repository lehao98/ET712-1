var a="4";
var b="Jason Ruan";
var c="Bayside,NY.";
var d="Programmer";

var e="You will be " + d + " in " + c + " And you married to " + b + " with " + a + " kids.";
console.log(e);
document.write(e);
